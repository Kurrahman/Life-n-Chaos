﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Globals : MonoBehaviour
{
    // Start is called before the first frame update
    public static int score = 0;
    public static float musicVolume = 1;
    public static float soundVolume = 1;
}
